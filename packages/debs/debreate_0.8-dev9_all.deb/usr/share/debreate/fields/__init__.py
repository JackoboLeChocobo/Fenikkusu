
# ******************************************************
# * Copyright © 2016-2017 - Jordan Irwin (AntumDeluge) *
# ******************************************************
# * This software is licensed under the MIT license.   *
# * See: LICENSE.txt for details.                      *
# ******************************************************

## User interface input fields
#
#  @package fields
